- Proyecto simple con JÇDBC y MySQL Driver, simulación ERP para un proyecto de clase.
Puedes agregar o modificar Clientes de la BBDD consultar productos ventas etc...

Pasos:


- Descargar y crear la BBDD en MySQL (ejecutarla)
- Configurar la Clase Conexión del paquete bbdd (puerto, nombre de la bbdd, usuario y password del Workbench)
- Al ejecutar para entrar Usuario : admin Password: 123456

