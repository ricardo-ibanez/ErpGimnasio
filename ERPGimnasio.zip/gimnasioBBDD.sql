
drop database if exists gimnasio;
create database gimnasio;
USE gimnasio;
CREATE TABLE Clientes (
    NumeroSocio  INT  PRIMARY KEY AUTO_INCREMENT ,
    DNI VARCHAR(15) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Apellido VARCHAR(50) NOT NULL,
    NumeroTelefono VARCHAR(15) NOT NULL
   
);
CREATE TABLE Productos (
    IDProducto INT PRIMARY KEY,
    NombreProducto VARCHAR(50) NOT NULL,
    Precio DECIMAL(10, 2) NOT NULL
);
CREATE TABLE Facturas (
    NumeroFactura INT PRIMARY KEY ,
    PrecioTotal DECIMAL(10, 2) NOT NULL,
    NumeroSocio INT NOT NULL,
    FOREIGN KEY (NumeroSocio) REFERENCES Clientes(NumeroSocio)
);
CREATE TABLE FacturasProductos (
	ID_FP INT PRIMARY KEY UNIQUE NOT NULL AUTO_INCREMENT,
    NumeroFactura INT,
    IDProducto INT,
    Cantidad INT,
    FOREIGN KEY (NumeroFactura) REFERENCES Facturas(NumeroFactura),
    FOREIGN KEY (IDProducto) REFERENCES Productos(IDProducto)
);

-- Nombre producto , Precio , cantidad y SUM PRECIOS

-- Insertar datos en la tabla Clientes
INSERT INTO Clientes (NumeroSocio, DNI, Nombre, Apellido, NumeroTelefono)
VALUES
    (1, '12345678A', 'Juan', 'Gómez', '123456789'),
    (2, '23456789B', 'María', 'López', '987654321'),
    (3, '34567890C', 'Pedro', 'Martínez', '654321987'),
    (4, '45678901D', 'Ana', 'Rodríguez', '789012345'),
    (5, '56789012E', 'Carlos', 'García', '234567890'),
    (6, '67890123F', 'Laura', 'Fernández', '876543210'),
    (7, '78901234G', 'Pablo', 'Hernández', '345678901'),
    (8, '89012345H', 'Carmen', 'Sánchez', '901234567'),
    (9, '90123456I', 'Javier', 'Pérez', '432109876'),
    (10, '01234567J', 'Isabel', 'Díaz', '210987654'),
    (11, '12345678K', 'Miguel', 'Vargas', '543210987'),
    (12, '23456789L', 'Rosa', 'Romero', '678901234'),
    (13, '34567890M', 'Sergio', 'Jiménez', '789012345'),
    (14, '45678901N', 'Elena', 'Torres', '890123456'),
    (15, '56789012O', 'Francisco', 'Navarro', '901234567'),
    (16, '67890123P', 'Silvia', 'Gutiérrez', '123456789'),
    (17, '78901234Q', 'Antonio', 'López', '234567890'),
    (18, '89012345R', 'Beatriz', 'Fuentes', '345678901'),
    (19, '90123456S', 'Diego', 'Gómez', '456789012'),
    (20, '01234567T', 'Lorena', 'Martínez', '567890123'),
    (21, '75778905T', 'Manueh', 'Garrido', '665768796'),
    (22, '77658905T', 'Marina', 'Moratalla', '662657643');

-- Insertar datos en la tabla Productos
INSERT INTO Productos (IDProducto, NombreProducto, Precio)
VALUES
    (1, 'Mancuerna de 20 Kg', 50.00),
    (2, 'Maquina de Remo', 800.00),
    (3, 'Press banca', 120.00),
    (4, 'Maquina Polea', 600.00),
    (5, 'Press de Pierna', 150.00),
    (6, 'Cinta de Correr', 700.00),
    (7, 'Bicicleta Estacionaria', 350.00),
    (8, 'Banco de Pesas', 180.00),
    (9, 'Balón Medicinal', 25.00),
    (10, 'Cuerda para Saltar', 10.00),
    (11, 'Barra Olímpica', 120.00),
    (12, 'Guantes de Levantamiento', 15.00),
    (13, 'Bandas de Resistencia', 30.00),
    (14, 'Rueda Abdominal', 20.00),
    (15, 'Calcetines Deportivos', 8.00),
    (16, 'Gel Energético', 3.50),
    (17, 'Botella de Agua Deportiva', 5.00),
    (18, 'Toalla Deportiva', 12.00),
    (19, 'Auriculares Deportivos', 25.00),
    (20, 'Cuerda Elástica', 18.00);

-- Insertar datos en la tabla Facturas
INSERT INTO Facturas (NumeroFactura, PrecioTotal, NumeroSocio)
VALUES
    (1, 200.00, 1),
    (2, 1000.00, 2),
    (3, 500.00, 3),
    (4, 300.00, 4),
    (5, 800.00, 5),
    (6, 250.00, 6),
    (7, 1500.00, 7),
    (8, 120.00, 8),
    (9, 450.00, 9),
    (10, 700.00, 10),
    (11, 320.00, 11),
    (12, 180.00, 12),
    (13, 90.00, 13),
    (14, 420.00, 14),
    (15, 50.00, 15),
    (16, 30.00, 16),
    (17, 70.00, 17),
    (18, 25.00, 18),
    (19, 35.00, 19),
    (20, 120.00, 20),
    (21, 160.00, 21),
    (22, 120.00, 22);

-- Insertar datos en la tabla FacturasProductos
INSERT INTO FacturasProductos (NumeroFactura, IDProducto, Cantidad)
VALUES
    (1, 1, 2),
    (1, 3, 1),
    (1, 2, 1),
    (2, 2, 1),
    (2, 4, 3),
    (2, 7, 3),
    (3, 5, 2),
    (3, 6, 1),
    (3, 7, 1),
    (4, 7, 1),
    (4, 8, 2),
    (4, 12, 2),
    (5, 9, 3),
    (5, 10, 1),
    (5, 5, 1),
    (6, 11, 2),
    (6, 12, 1),
    (6, 10, 1),
    (7, 13, 1),
    (7, 14, 2),
    (7, 15, 2),
    (8, 15, 1),
    (8, 16, 3),
    (8, 4, 3),
    (9, 17, 2),
    (9, 18, 1),
    (9, 10, 1),
    (10, 19, 1),
    (10, 20, 2),
    (10, 5, 2),
    (21,15,3),
    (21,17,2),
    (21,5,1),
    (22,8,4),
    (22,12,3),
    (22,2,2);
